# Readme Install Windows 10 and use virtualenv

# Install virtualenv
pip install virtualenv

# Go to project directory
cd <project directory>

# Create virtualenv "my_virt"
 virtualenv my_virt

 # Activate "my_virt"
 source my_virt/Scripts/activate

 # Resources
 https://www.liquidweb.com/kb/how-to-setup-a-python-virtual-environment-on-windows-10/