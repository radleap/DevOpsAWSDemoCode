# README - Instructions

https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/create-deploy-python-flask.html