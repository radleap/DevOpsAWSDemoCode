# README - Instructions

https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/create-deploy-python-flask.html

## Resources
https://nadaa-taiyab.medium.com/how-to-dockerize-your-flask-app-and-deploy-to-aws-elastic-beanstalk-9f761b7f3dba